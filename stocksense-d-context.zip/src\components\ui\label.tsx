import type * as React from 'react';

import { cn } from '@/lib/utils';

function Label({ className, ...props }: React.ComponentProps<'label'>) {
  return (
    <label
      data-slot="label"
      className={cn('text-sm font-medium leading-none select-none peer-disabled:opacity-50', className)}
      {...props}
    />
  );
}

export { Label };
